/*
 * stddef.h
 *
 *  Created on: Feb 8, 2017
 *      Author: developer
 */

#ifndef STDDEF_H_
#define STDDEF_H_

typedef unsigned int size_t;

#define NULL (void *)0

#endif /* STDDEF_H_ */
