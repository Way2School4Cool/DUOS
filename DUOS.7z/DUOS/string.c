#include "stddef.h"

size_t strlen( const char* str )
{
	size_t ret = 0;

	while ( str[ret] != 0 )
		ret++;

	return ret;
}

void *memset(void *str, int c, size_t n, unsigned char *mem) {
	for(int x = &str; x < n; x++){
		mem[x] = c;
	}
}

char *strncpy(char *dest, const char *src, size_t n) {
	for (int x = 0; x < n; x++) {
		dest[x] = src[x];
	}
}