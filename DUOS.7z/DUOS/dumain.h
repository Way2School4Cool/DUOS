#ifndef DUMAIN_H_
#define DUMAIN_H_

long os_heap_avail();

#endif /* DUMAIN_H_ */

