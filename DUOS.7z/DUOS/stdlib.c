/*
 * stdlib.c
 *
 *  Created on: Feb 8, 2017
 *      Author: developer
 */

#include "stddef.h"
#include "string.h"

char *ltoa( long value, char *str, int base )
{
	unsigned char byte = '\0';
	char ch = '\0';
	int index = 7;

	if( base == 16 )
	{
		for ( int i = 0; i <= 24; i+= 8 )
		{
			byte = (unsigned char)(value >> i);

			// extract the first nibble and assign a character
			if ((byte & 0x0F) < 10)
				ch = 48 + (byte & 0x0F); // 0 - 9
			else
				ch = 55 + (byte & 0x0F); // A - F
			str[index] = ch;
			index--;

			// extract the second nibble and assign a character
			byte = (byte >> 4);
			if ((byte & 0x0F) < 10)
				ch = 48 + (byte & 0x0F); // 0 - 9
			else
				ch = 55 + (byte & 0x0F); // A - F
			str[index] = ch;
			index--;
		}
	}
	
	return NULL;
}

//S
void *malloc(int size, unsigned char *mem, int index, int *loc) {
	void *pMem;
	int totalSize = 1048576;
	
	//if the size to be allocated is too great, DO NOT ALLOCATE
	if((size + index) > totalSize) {
		return '\0';
	}
		
	//set return value to the start of allocated area
	pMem = mem[index];
	
	//set index to the end of allocated area
	index += size;
	
	*loc = index;
	
	//return pointer to start of allocated area
	return pMem;
}


void free(void *ptr, unsigned char *mem, int index, int *loc) {
	//if the pointed field is less than the last indexed space
	if (&ptr < &loc) {
		//loop through from pointed field to index and clear all allocated data;
		for (int x = &ptr; x <= index; x++) {
			mem[x] = '\0';
		}
		index = &ptr;
		*loc = 0;
	}
}
